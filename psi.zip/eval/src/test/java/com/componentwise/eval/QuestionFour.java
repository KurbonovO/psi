package com.componentwise.eval;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Hashtable;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class QuestionFour {

	@Test
	public void test() {

		UserKey b1 = new UserKey("Bill Smith", "BSMITH");
		UserKey b2 = new UserKey("Bill Smith", "BSMITH");
		UserKey b3 = new UserKey("Susan Smith", "SSMITH");
		UserKey b4 = new UserKey(null, null);

		assertEquals(b1, b1);
		assertEquals(b1, b2); // prints true
		assertNotEquals(b1, b3); // prints false
		assertNotEquals(b1, null); // prints false
		assertNotEquals(b1, "Some String"); // prints false
		assertNotEquals(b4, b1); // prints false

		Hashtable<UserKey, String> ht = new Hashtable<UserKey, String>();

		ht.put(b1, "Some Data");

		String s = (String) ht.get(b1);

		assertEquals(s, "Some Data"); // prints true
	}

}
