package com.componentwise.eval;

import java.util.Date;

public class QuestionThree {

	/**
	 * Idicated wheather manager or not
	 */
	private Boolean managerFlag;

	/**
	 * Name of the employee
	 */
	private String name;

	/**
	 * Date of which employee is hired
	 */
	private Date dateHired;

	/**
	 * Id of the employee
	 */
	private Integer id;

	/**
	 * if True its full time employee else part time.
	 */
	private Boolean fullTimeOrPartTime;

	/**
	 * When the part time employee clocks in
	 */
	private Date clockIn;

	/**
	 * When the part time employee clock out
	 */
	private Date clockOut;

	/**
	 * When employee regular non over time hours
	 */
	private Long nonOverTime;

	/**
	 * When the part time employee goes over time
	 */
	private Long overTime;

	public Boolean getManagerFlag() {
		return managerFlag;
	}

	public void setManagerFlag(Boolean managerFlag) {
		this.managerFlag = managerFlag;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateHired() {
		return dateHired;
	}

	public void setDateHired(Date dateHired) {
		this.dateHired = dateHired;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getFullTimeOrPartTime() {
		return fullTimeOrPartTime;
	}

	public void setFullTimeOrPartTime(Boolean fullTimeOrPartTime) {
		this.fullTimeOrPartTime = fullTimeOrPartTime;
	}

	public Date getClockIn() {
		return clockIn;
	}

	public void setClockIn(Date clockIn) {
		this.clockIn = clockIn;
	}

	public Date getClockOut() {
		return clockOut;
	}

	public void setClockOut(Date clockOut) {
		this.clockOut = clockOut;
	}

	public Long getNonOverTime() {
		return nonOverTime;
	}

	public void setNonOverTime(Long nonOverTime) {
		this.nonOverTime = nonOverTime;
	}

	public Long getOverTime() {
		return overTime;
	}

	public void setOverTime(Long overTime) {
		this.overTime = overTime;
	}

	@Override
	public String toString() {
		return "QuestionThree [managerFlag=" + managerFlag + ", name=" + name + ", dateHired=" + dateHired + ", id="
				+ id + ", fullTimeOrPartTime=" + fullTimeOrPartTime + ", clockIn=" + clockIn + ", clockOut=" + clockOut
				+ ", nonOverTime=" + nonOverTime + ", overTime=" + overTime + "]";
	}

}
