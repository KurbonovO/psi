package com.componentwise.eval;

import java.util.ArrayList;
import java.util.List;

public class QuestionOne {

	/**
	 * First of all we check for open and close brackets and elements of it as well.
	 * And make a static element of it.
	 */
	private static final String openBracket = "<";
	private static final String openBracketClose = "</";
	private static final String closeBracket = ">";

	/**
	 * We create a pojo which it would have startElement, endElement and in between
	 * list of object and text elements.
	 */

	/**
	 * we create a validate method and purpose of it would be go trough the builded
	 * object and make sure it has the brackets, same elements case sensativity as
	 * we as the correct array structure for the child elements with its value
	 * stored. if valididated is true call in the addMetod.
	 */

	/**
	 * add method structure would be just to add the objects to the list of objects.
	 */

	/**
	 * time complexity would be O(n).
	 */

	public class XmlObject {

		private String startElement;
		private String endElement;
		private String textElement;
		private List<XmlObject> childs;

		public String getStartElement() {
			return startElement;
		}

		public void setStartElement(String startElement) {
			this.startElement = startElement;
		}

		public String getEndElement() {
			return endElement;
		}

		public void setEndElement(String endElement) {
			this.endElement = endElement;
		}

		public String getTextElement() {
			return textElement;
		}

		public void setTextElement(String textElement) {
			this.textElement = textElement;
		}

		public List<XmlObject> getChilds() {
			return childs;
		}

		public void setChilds(List<XmlObject> childs) {
			this.childs = childs;
		}

		@Override
		public String toString() {
			return "XmlObject [startElement=" + startElement + ", endElement=" + endElement + ", textElement="
					+ textElement + ", childs=" + childs + "]";
		}

		public boolean validate() {

			boolean res = true;

			if (this.getStartElement() == null || this.getEndElement() == null) {
				return false;
			}
			for (XmlObject obj : childs) {

				res = obj.validate();

				if (!res) {
					return false;
				}
			}
			return res;
		}

		public void addElement(XmlObject child) {

			if (childs == null) {
				childs = new ArrayList<>();
			}
			childs.add(child);
		}
	}
}
